#include<vector>
int play(int k);
void game(int x, int y, const std::vector<int> S);
