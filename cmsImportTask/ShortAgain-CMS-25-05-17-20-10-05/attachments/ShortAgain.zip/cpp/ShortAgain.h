#include <vector>
std::vector<int> construct(int n, int k);