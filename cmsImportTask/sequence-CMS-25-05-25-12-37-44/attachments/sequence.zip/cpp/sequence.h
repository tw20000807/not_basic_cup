void bob_init(int n);
int query_from_alice(int a);
int compare_numbers(int i, int j, int k);