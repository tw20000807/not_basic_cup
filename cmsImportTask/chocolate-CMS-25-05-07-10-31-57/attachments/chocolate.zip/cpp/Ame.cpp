#include <string>
std::string Ame(int n, int b){
	std::string ret(b, 'B');
	return ret;
}