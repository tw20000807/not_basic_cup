#include<string>
std::string Ame(int n, int b);
int Bla(int n, std::string s);