#include<vector>
std::vector<int> construct(const std::vector<int> v);
