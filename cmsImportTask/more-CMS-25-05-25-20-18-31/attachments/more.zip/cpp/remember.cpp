#include<vector>
using namespace std;
long long remember(std::vector<int> V){
    return V[0] + V[1];
}