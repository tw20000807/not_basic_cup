#include <string>
int Bla(int n, std::string s){
	return s.size();
}