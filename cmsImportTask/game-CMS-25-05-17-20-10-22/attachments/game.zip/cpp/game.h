#include<vector>
int play(int x, int y);
int game_start(int x, int y, std::vector<int> S);
